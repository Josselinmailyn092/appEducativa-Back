# Proyecto de Cálculo Básico

Este proyecto es una pequeña herramienta educativa para:
- Evaluar funciones f(x) (expresadas en JavaScript, por ejemplo `Math.sin(x)` o `x*x + 2*x + 1`).
- Calcular derivada numérica (diferencia centrada).
- Estimar integrales definidas usando la regla del trapecio.
- Graficar la función con Chart.js.

**Archivos**
- `index.html` — Interfaz web.
- `style.css` — Estilos simples.
- `script.js` — Lógica: evaluación, derivada, integral y gráfico.
- `README.md` — Este archivo.

**Advertencias**
- La función ingresada se evalúa con `new Function(...)` y `with(Math){...}` para permitir usar constantes y funciones de `Math`. Esto **no** es seguro para entradas de usuarios no confiables en producción. Es solamente para fines educativos.
- Reemplace o extienda el proyecto según sus necesidades (más métodos numéricos, validaciones, exportación de resultados, etc).

¡Listo para abrir `index.html` en tu navegador!
