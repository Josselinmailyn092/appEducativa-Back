// Evaluaciones y cálculo numérico simple
function safeEvalFunction(expr){
  // Crea una función de x a partir de la expresión ingresada por el usuario.
  // ADVERTENCIA: usa Function() — para propósitos educativos. No usar con entradas no confiables en producción.
  try{
    return new Function("x","with(Math){return " + expr + "}"); // permite Math.sin, etc.
  }catch(e){
    return null;
  }
}

function evalAt(func, x){
  try{
    return Number(func(x));
  }catch(e){
    return NaN;
  }
}

function numericDerivative(func, x, h=1e-6){
  // Diferencia centrada
  return (evalAt(func, x + h) - evalAt(func, x - h)) / (2*h);
}

function trapezoidalIntegral(func, a, b, n){
  a = Number(a); b = Number(b); n = parseInt(n);
  if(n <= 0) return NaN;
  var h = (b - a)/n;
  var sum = 0.5 * (evalAt(func,a) + evalAt(func,b));
  for(var i=1;i<n;i++){
    var xi = a + i*h;
    sum += evalAt(func, xi);
  }
  return sum * h;
}

// DOM
document.getElementById("evalBtn").addEventListener("click", ()=>{
  var expr = document.getElementById("func").value;
  var x = Number(document.getElementById("xval").value);
  var f = safeEvalFunction(expr);
  var out = document.getElementById("results");
  if(!f){ out.innerText = "Expresión inválida."; return; }
  var fx = evalAt(f,x);
  var dfx = numericDerivative(f,x);
  out.innerHTML = "f(" + x + ") = " + fx + "<br>f'(" + x + ") ≈ " + dfx;
});

document.getElementById("intBtn").addEventListener("click", ()=>{
  var expr = document.getElementById("func").value;
  var a = Number(document.getElementById("a").value);
  var b = Number(document.getElementById("b").value);
  var n = Number(document.getElementById("n").value);
  var f = safeEvalFunction(expr);
  var out = document.getElementById("intRes");
  if(!f){ out.innerText = "Expresión inválida."; return; }
  var I = trapezoidalIntegral(f,a,b,n);
  out.innerHTML = "∫ from " + a + " to " + b + " f(x) dx ≈ " + I;
});

// Plot with Chart.js
var chart = null;
document.getElementById("plotBtn").addEventListener("click", ()=>{
  var expr = document.getElementById("func").value;
  var xmin = Number(document.getElementById("xmin").value);
  var xmax = Number(document.getElementById("xmax").value);
  var points = parseInt(document.getElementById("points").value);
  var f = safeEvalFunction(expr);
  if(!f){ alert("Expresión inválida."); return; }
  var xs = [], ys = [];
  for(var i=0;i<points;i++){
    var t = xmin + (xmax - xmin) * i / (points-1);
    xs.push(t.toFixed(4));
    var y = evalAt(f,t);
    if(!isFinite(y)) y = NaN;
    ys.push(y);
  }
  var ctx = document.getElementById("chart").getContext("2d");
  if(chart) chart.destroy();
  chart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: xs,
      datasets: [{ label: 'f(x)', data: ys, fill:false }]
    },
    options: {
      scales: { x: { display: true }, y: { display: true } },
      elements: { point: { radius: 0 } }
    }
  });
});
